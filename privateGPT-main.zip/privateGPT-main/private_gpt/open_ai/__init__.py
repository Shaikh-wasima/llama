"""OpenAI compatibility utilities."""

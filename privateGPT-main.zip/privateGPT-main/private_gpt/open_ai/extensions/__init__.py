"""OpenAI API extensions."""
